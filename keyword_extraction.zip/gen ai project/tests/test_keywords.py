"""Basic tests for the keyword extraction helper."""

from app import extract_keywords


def test_extract_keywords_returns_keywords():
    text = "Emma investigated the scandal and uncovered corruption in the city."
    result = extract_keywords(text, ratio=0.5, max_keywords=10)
    assert isinstance(result, list)
    assert len(result) > 0


def test_extract_keywords_handles_blank_text():
    assert extract_keywords("   ") == []


def test_extract_keywords_limits_keyword_count():
    text = " ".join(["investigation" for _ in range(50)])
    result = extract_keywords(text, ratio=0.9, max_keywords=3)
    assert len(result) <= 3
