# Keyword Extraction Lab

A Streamlit web application that uses TF-IDF ranking (via scikit-learn) to extract the most relevant keywords from any passage of text. Built to assist investigative journalists and researchers who need to sift quickly through large corpora and surface the essential concepts.

## Features
- Paste or type any text, or upload a `.txt/.md` document, then extract keywords with one click.
- Tune keyword density, maximum keyword count, and an optional normalization toggle.
- Stylish, website-like Streamlit UI with hero banner, metrics, FAQ, download button, and responsive layout.

## Requirements
- Python 3.10+
- See `requirements.txt` for Python dependencies (`streamlit`, `scikit-learn`).

## Local Development / Hosting
1. **Clone or download** this project into your workspace.
2. **Create a virtual environment** (recommended):
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```
3. **Install dependencies**:
   ```bash
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
   ```
4. **Run the Streamlit server**:
   ```bash
   streamlit run app.py
   ```
5. **Open the browser** at the URL printed in the terminal (default `http://localhost:8501`).

### Deploying
- **Streamlit Community Cloud**: push this folder to GitHub, then use the Streamlit Cloud dashboard to point to `app.py`.
- **Render / Railway / Heroku**: create a web service, set the start command to `streamlit run app.py --server.port $PORT --server.address 0.0.0.0`.
- **Docker (optional)**: create an image from `python:3.11-slim`, copy the repo, install requirements, expose desired port, and run the same Streamlit command as above.

## Testing & Validation
- The logic for keyword extraction lives in `extract_keywords`. You can validate it with `pytest` (after installing `pytest`) using the tests in `tests/`.
- Manual validation: run the app, paste both short and long texts, upload `.txt` files, and confirm that adjusting sliders changes the keyword output as expected.

## Project Structure
```
app.py             # Streamlit application entrypoint
README.md          # Documentation & hosting instructions
requirements.txt   # Dependencies
tests/             # Pytest smoke tests
```
