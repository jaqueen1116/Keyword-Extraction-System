"""Streamlit-powered keyword extraction website for investigative work."""
from __future__ import annotations

import re
from pathlib import Path
from typing import List, Sequence

import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer


def simple_normalize(token: str) -> str:
    """Apply a lightweight stemming-like normalization."""
    endings = ("ingly", "edly", "ing", "ed", "ly", "es", "s")
    for ending in endings:
        if token.endswith(ending) and len(token) - len(ending) >= 3:
            return token[: -len(ending)]
    return token


def preprocess_text(text: str, normalize: bool) -> str:
    tokens = re.findall(r"[A-Za-z]+", text.lower())
    if normalize:
        tokens = [simple_normalize(tok) for tok in tokens]
    return " ".join(tokens)


def extract_keywords(
    text: str,
    ratio: float = 0.2,
    max_keywords: int | None = 20,
    use_lemmatization: bool = True,
) -> List[str]:
    """Extract keywords by ranking TF-IDF scores."""
    clean_text = (text or "").strip()
    if not clean_text:
        return []

    processed = preprocess_text(clean_text, normalize=use_lemmatization)
    if not processed:
        return []

    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    tfidf_matrix = vectorizer.fit_transform([processed])
    feature_names = vectorizer.get_feature_names_out()
    scores = tfidf_matrix.toarray().flatten()

    ranked = sorted(zip(scores, feature_names), key=lambda item: item[0], reverse=True)
    if not ranked:
        return []

    ratio_limit = max(1, int(len(ranked) * ratio))
    hard_limit = max_keywords or len(ranked)
    final_limit = max(1, min(ratio_limit, hard_limit))

    return [term for _, term in ranked[:final_limit]]


def init_page_style() -> None:
    st.set_page_config(
        page_title="Keyword Extraction Lab",
        page_icon="🗝️",
        layout="wide",
    )
    st.markdown(
        """
        <style>
            .hero {
                padding: 1.5rem;
                background: linear-gradient(135deg, #0f172a, #1d4ed8);
                border-radius: 1rem;
                color: white;
                margin-bottom: 2rem;
            }
            .hero h1 {
                margin-bottom: 0.5rem;
            }
            .section-card {
                padding: 1.25rem;
                border: 1px solid rgba(15, 23, 42, 0.1);
                border-radius: 1rem;
                background: white;
                box-shadow: 0 5px 25px rgb(15 23 42 / 8%);
            }
            .keyword-pill {
                display: inline-block;
                padding: 0.35rem 0.9rem;
                margin: 0.25rem;
                border-radius: 999px;
                background: #e0f2fe;
                color: #0f172a;
                font-weight: 600;
            }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_results(keywords_list: Sequence[str]) -> None:
    container = st.container()
    with container:
        if not keywords_list:
            st.warning("No keywords found. Please provide more detailed text.")
            return

        st.success(f"Found {len(keywords_list)} keywords")
        st.markdown(
            "".join(f'<span class="keyword-pill">{word}</span>' for word in keywords_list),
            unsafe_allow_html=True,
        )
        st.download_button(
            label="Download keywords (.txt)",
            data="\n".join(keywords_list),
            file_name="keywords.txt",
            mime="text/plain",
            use_container_width=True,
        )


def load_text_from_file(upload) -> str:
    if upload is None:
        return ""
    suffix = Path(upload.name).suffix.lower()
    raw = upload.read()
    if suffix in {".txt", ".md"}:
        return raw.decode("utf-8", errors="ignore")
    st.warning("Unsupported file type. Please upload a plain-text document.")
    return ""


def hero_section() -> None:
    st.markdown(
        """
        <div class="hero">
            <h1>Keyword Extraction: Navigating the Data Labyrinth</h1>
            <p>
                Surface the facts inside lengthy reports. Drop in any article, leak or memo
                and let TF-IDF scoring spotlight the ideas worth chasing.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def sidebar_content() -> tuple[float, int, bool]:
    with st.sidebar:
        st.header("Controls")
        ratio = st.slider(
            "Keyword density",
            min_value=0.05,
            max_value=0.9,
            value=0.35,
            step=0.05,
            help="Higher values return more keywords.",
        )
        max_keywords = st.slider(
            "Maximum keywords",
            min_value=5,
            max_value=80,
            value=25,
            step=1,
        )
        use_lemmatization = st.toggle(
            "Normalize words",
            value=True,
            help="Applies lightweight stemming to group similar terms.",
        )
        st.divider()
        st.caption("Need help? Scroll down to the FAQ section.")
    return ratio, max_keywords, use_lemmatization


def insights_section(text: str) -> None:
    if not text:
        return
    cols = st.columns(3)
    words = len(text.split())
    chars = len(text)
    sentences = text.count(".") + text.count("!") + text.count("?")
    cols[0].metric("Words analyzed", f"{words:,}")
    cols[1].metric("Characters", f"{chars:,}")
    cols[2].metric("Sentences (approx.)", max(1, sentences))


def faq_section() -> None:
    with st.expander("How does this work?"):
        st.write(
            "We vectorize the document with TF-IDF, then surface the highest-scoring "
            "tokens and bigrams. TF-IDF rewards terms that appear often in your text, yet "
            "are uncommon in general writing."
        )
    with st.expander("How accurate is it?"):
        st.write(
            "TF-IDF performs well on news and report-style prose. Adjust the density "
            "slider or limit the number of keywords to fine-tune results."
        )
    with st.expander("Can I download the keywords?"):
        st.write("Yes—after extraction click the download button to save them as text.")


def streamlit_app() -> None:
    init_page_style()
    hero_section()

    ratio, max_keywords, use_lemmatization = sidebar_content()
    sample_text = (
        "In a bustling city where information overflowed like a torrent, Emma, an "
        "aspiring journalist, struggled to uncover the truth amidst a sea of noise."
        " Assigned to investigate a high-profile scandal, she turned to data-driven "
        "methods to separate fact from fiction."
    )

    col_input, col_preview = st.columns((2, 1))
    with col_input:
        upload = st.file_uploader("Upload a document (.txt/.md)", type=["txt", "md"])
        uploaded_text = load_text_from_file(upload)
        text_input = st.text_area(
            "Paste or type the text you want to analyze",
            value=uploaded_text or sample_text,
            height=240,
        )
        insights_section(text_input)
        submit = st.button("Extract keywords", type="primary", use_container_width=True)

    with col_preview:
        st.markdown("### Live preview")
        st.write(
            "Use the sidebar controls to tune the extraction. Uploads override any text "
            "entered manually."
        )
        st.image(
            "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&w=600",
            caption="Data sleuthing in action.",
            use_column_width=True,
        )

    if submit:
        results = extract_keywords(
            text_input,
            ratio=ratio,
            max_keywords=max_keywords,
            use_lemmatization=use_lemmatization,
        )
        render_results(results)
    else:
        st.info('Adjust the controls, then click "Extract keywords".')

    st.divider()
    faq_section()


def main() -> None:
    streamlit_app()


if __name__ == "__main__":
    main()
